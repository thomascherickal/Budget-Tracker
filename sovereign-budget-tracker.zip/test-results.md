# Sovereign Budget - Test Execution Results

**Execution Timestamp**: `2026-10-24T12:07:03.647Z` (Sat, 24 Oct 2026 12:07:03 GMT)  
**Environment**: Node.js `v24.19.0` (linux x64)  
**Overall Status**: ✅ **ALL TESTS PASSED (100% Line Coverage)**

## 1. Summary Statistics

| Metric | Count | Status |
| :--- | :---: | :--- |
| **Total Tests** | **109** | Complete suite |
| **Passed** | **109** | ✅ 100% Pass Rate |
| **Failed** | **0** | ✅ 0 Failures |
| **Skipped** | **0** | ✅ 0 Skipped |
| **Execution Time** | **4.56s** (`4556.92ms`) | High performance |

## 2. Code Coverage Breakdown

| Target File | Line Coverage | Branch Coverage | Function Coverage | Uncovered Lines |
| :--- | :---: | :---: | :---: | :--- |
| `app.js` | 100.00% | 81.01% | 89.80% | None |
| `js/constants.js` | 100.00% | 100.00% | 100.00% | None |
| `js/crypto.js` | 100.00% | 91.67% | 100.00% | None |
| `js/currencies.js` | 100.00% | 90.32% | 100.00% | None |
| `js/financials.js` | 100.00% | 83.69% | 87.50% | None |
| `js/storage.js` | 100.00% | 93.65% | 100.00% | None |
| `js/ui.js` | 100.00% | 94.83% | 100.00% | None |
| **All Files** | **100.00%** | **85.03%** | **90.86%** | **None** |

## 3. Test Suites Executed

- ✔ Application Orchestrator Suite (`tests/app.test.js`)
- ✔ Constants Definition Suite (`tests/constants.test.js`)
- ✔ Currencies & Internationalization Suite (`tests/currencies.test.js`)
- ✔ Crypto Module Suite (`tests/crypto.test.js`)
- ✔ AES-256-GCM Encryption Suite (`tests/encryption.test.js`)
- ✔ Financial Calculations Engine Suite (`tests/financials.test.js`)
- ✔ Storage Persistence & Autosave Suite (`tests/storage.test.js`)
- ✔ UI Helpers & DOM Sync Suite (`tests/ui.test.js`)
- ✔ End-to-End Integration Lifecycle Suite (`tests/integration.test.js`)

## 4. Execution Log & Verification

<details>
<summary>Click to view raw test runner output</summary>

```text
▶ Application Orchestrator Suite (app.js Full Lifecycle)
  ✔ should boot application, load cache, and render initial views (27.368639ms)
  ✔ should switch tabs across all panels and update header titles (4.629403ms)
  ✔ should navigate months forward and backward (2.181812ms)
  ✔ should submit quick transaction form with valid and invalid inputs (2.270265ms)
  ✔ should submit modal transaction form with valid and invalid inputs (2.025249ms)
  ✔ should update savings requirement setting (1.78152ms)
  ✔ should add and delete recurring and one-time planned expenses (4.266157ms)
  ✔ should change currency and update state and dropdowns (5.952259ms)
  ✔ should filter transactions by search, type, category and reset (2.625452ms)
  ✔ should handle export operations (plain and encrypted) (47.87155ms)
  ✔ should handle plain and encrypted import flows (2.088555ms)
  ✔ should clear local memory and restart fresh (1.522822ms)
  ✔ should trigger window resize and dispatch keyboard escape dismissal (2.05523ms)
  ✔ should return null when document is undefined or null (0.168018ms)
  ✔ should exercise dashboard savings variations and negative balance (4.969505ms)
  ✔ should exercise delete buttons on rendered tables (2.418207ms)
  ✔ should exercise chart rendering with Chart mock and callback handlers (1.667936ms)
Service Worker registered successfully. /
  ✔ should exercise handleImportJSON with mock FileReader (21.79474ms)
  ✔ should exercise service worker load event listener (2.775922ms)
  ✔ should initialize lucide icons when lucide is globally present (1.222007ms)
  ✔ should notify when autosaved budget is loaded with existing records (452.167272ms)
  ✔ should handle loadData catch block when storage throws (0.83863ms)
  ✔ should handle saveData catch block when storage quota is exceeded (0.627738ms)
  ✔ should handle export error gracefully in exportPlainJSON and exportDatabaseBackup (19.731455ms)
  ✔ should handle cancelled and corrupted processImportedContent flows (1.493991ms)
  ✔ should exercise interactive event listeners for nav, mobile-nav, scope tabs, clear db, backdrop, and type changes (3.2233ms)
  ✔ should validate rejection paths in formAddRecurring and formAddOnetime (0.450221ms)
  ✔ should filter transactions by specific category in renderTransactionsLog (0.529848ms)
  ✔ should exercise window resize when AppState.currentTab is reports (250.844032ms)
  ✔ should initialize db.settings.currency during init when currency setting is absent (0.976337ms)
  ✔ should test DOMContentLoaded registration when document is available (0.664654ms)
  ✔ should exercise dashboard savings target achieved message (1.095987ms)
✔ Application Orchestrator Suite (app.js Full Lifecycle) (885.216584ms)
▶ Constants Suite
  ✔ should verify storage cache and autosave keys (1.035664ms)
  ✔ should define valid expense and income category arrays (0.407971ms)
  ✔ should define valid chart palette and tab titles (0.520703ms)
  ✔ should attach properties to window in browser environment (2.246561ms)
✔ Constants Suite (6.309873ms)
▶ Crypto Module Suite
  ✔ should convert ArrayBuffer to Base64 and back across diverse byte lengths (2.337355ms)
  ✔ should test browser fallback conversion loops using btoa and atob (0.509707ms)
  ✔ should sanitize username during hashing (trimming and lowercasing) (14.341957ms)
  ✔ should derive a valid CryptoKey from PBKDF2 (23.768059ms)
  ✔ should encrypt and decrypt plaintext payloads accurately (60.121084ms)
  ✔ should reject decryption with incorrect username (59.83809ms)
  ✔ should reject invalid or tampered envelopes (40.903719ms)
  ✔ should throw WebCrypto API not available if crypto is missing (0.542077ms)
  ✔ should attach properties to window in browser environment (0.306105ms)
✔ Crypto Module Suite (206.709454ms)
▶ Currencies Suite
  ✔ should accurately detect currency from exact BCP-47 locale tags (3.425184ms)
  ✔ should match currency by language prefix if exact regional locale is absent (1.171862ms)
  ✔ should fallback to USD and $ for completely unknown locales or missing params in Node (0.384102ms)
  ✔ should detect user currency from navigator.language and navigator.languages in browser (0.144988ms)
  ✔ should resolve correct symbol for currency codes (0.148835ms)
  ✔ should resolve correct locale for currency codes (0.220364ms)
  ✔ should detect currencies for newly added countries and territories (0.267434ms)
  ✔ should resolve correct symbols for expanded currency options (0.356154ms)
  ✔ should format numerical amounts into localized currency strings (15.451583ms)
  ✔ should gracefully handle invalid currency codes with fallback formatting (0.358039ms)
  ✔ should fallback to en-US when window navigator lacks language properties (0.130975ms)
  ✔ should attach properties to window in browser environment (0.946951ms)
✔ Currencies Suite (26.452069ms)
▶ Cryptography Suite
  ✔ should convert ArrayBuffer to Base64 and back (4.911362ms)
  ✔ should sanitize username during hashing (case-insensitive and trim) (8.914386ms)
  ✔ should encrypt and decrypt data correctly with the correct username (54.391033ms)
  ✔ should fail decryption if an incorrect username is provided (60.377165ms)
  ✔ should succeed decryption with variations in whitespace and casing of the correct username (67.808158ms)
✔ Cryptography Suite (199.4566ms)
▶ Financial Calculations Suite
  ✔ should calculate financials correctly for a specific month (1.534751ms)
  ✔ should compute correct savings progress when surplus is below the requirement (0.378319ms)
  ✔ should clamp savings progress to 0% if actual surplus is negative (1.220067ms)
  ✔ should return 100% savings progress if savings requirement is 0 (0.194027ms)
  ✔ should throw an error if database state is missing (1.413435ms)
  ✔ should compile weekly report metrics accurately (22.070582ms)
  ✔ should compile monthly report metrics split into weeks (0.74014ms)
  ✔ should compile annual report metrics split into 12 months (0.440014ms)
  ✔ should generate appropriate diagnostic insights (0.507754ms)
  ✔ should gracefully handle empty or malformed database fields in getMonthFinancials (0.271901ms)
  ✔ should handle default arguments and edge cases in compileReportMetrics (1.572402ms)
  ✔ should attach properties to window in browser environment (0.659225ms)
✔ Financial Calculations Suite (35.079046ms)
▶ Integration Lifecycle Suite
  ✔ should successfully export and import a backup using matching usernames (75.755178ms)
  ✔ should block import and throw error if decryption username does not match export username (62.62421ms)
  ✔ should abort export if username prompt is cancelled (0.84216ms)
  ✔ should abort export and show warning if username prompt is empty (0.258187ms)
  ✔ should abort import if import username prompt is cancelled (27.042936ms)
  ✔ should abort import and show warning if import username is empty (19.83061ms)
  ✔ should support backward-compatibility for importing legacy unencrypted database schema without prompt (0.397124ms)
  ✔ should test currency symbol, locale mappings, and user currency detection logic (0.547117ms)
  ✔ should test autosave JSON serialization on exit and import on startup (0.176541ms)
  ✔ should test clear local memory and starting from scratch (0.15279ms)
✔ Integration Lifecycle Suite (193.082305ms)
▶ Storage Module Suite
  ✔ should return a valid clean database template (2.795972ms)
  ✔ should validate database schema accurately (0.265725ms)
  ✔ should persist data to both primary cache and autosave keys (0.656936ms)
  ✔ should handle storage errors gracefully in saveDataToStorage (0.994154ms)
  ✔ should load data prioritizing autosaved JSON export on startup (0.632634ms)
  ✔ should clear local memory keys safely and catch errors (0.279122ms)
  ✔ should create valid plain JSON export package (0.269162ms)
  ✔ should create encrypted backup and parse it back upon import (98.445917ms)
  ✔ should setup exit autosave event listeners on window and document (0.493081ms)
  ✔ should attach properties to window in browser environment (0.433871ms)
✔ Storage Module Suite (110.024474ms)
▶ UI Helpers Suite
  ✔ should calculate next and previous months with proper year rollover (1.636077ms)
  ✔ should format YYYY-MM into human-readable month labels and handle fallbacks (18.06615ms)
  ✔ should simulate DOM operations without crashing in headless environment (5.955577ms)
  ✔ should gracefully handle missing DOM elements in ui functions (0.475923ms)
  ✔ should handle headless environment safely when document is undefined (0.570479ms)
  ✔ should attach properties to window in browser environment (0.90702ms)
✔ UI Helpers Suite (30.269538ms)
ℹ tests 109
ℹ suites 0
ℹ pass 109
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 4556.918958
ℹ start of coverage report
ℹ ---------------------------------------------------------------
ℹ file           | line % | branch % | funcs % | uncovered lines
ℹ ---------------------------------------------------------------
ℹ app.js         | 100.00 |    81.01 |   89.80 | 
ℹ js             |        |          |         | 
ℹ  constants.js  | 100.00 |   100.00 |  100.00 | 
ℹ  crypto.js     | 100.00 |    91.67 |  100.00 | 
ℹ  currencies.js | 100.00 |    90.32 |  100.00 | 
ℹ  financials.js | 100.00 |    83.69 |   87.50 | 
ℹ  storage.js    | 100.00 |    93.65 |  100.00 | 
ℹ  ui.js         | 100.00 |    94.83 |  100.00 | 
ℹ ---------------------------------------------------------------
ℹ all files      | 100.00 |    85.03 |   90.86 | 
ℹ ---------------------------------------------------------------
ℹ end of coverage report
```
</details>
